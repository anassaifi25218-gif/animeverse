let anime = [];

const grid = document.getElementById("grid");
const empty = document.getElementById("empty");
const search = document.getElementById("search");
const category = document.getElementById("category");

function esc(s) {
  return String(s || "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
}
function render() {
  const q = search.value.toLowerCase().trim();
  const cat = category.value;
  const filtered = anime.filter(a =>
    (!q || a.title.toLowerCase().includes(q)) && (!cat || a.category === cat)
  );
  grid.innerHTML = filtered.map(a => `
    <a class="card" href="/watch.html?id=${a.id}">
      <div class="poster">${a.poster ? `<img src="${a.poster}" alt="">` : "<span>ANIME</span>"}</div>
      <h3>${esc(a.title)}</h3>
      <p>${esc(a.category)}</p>
    </a>`).join("");
  empty.hidden = filtered.length !== 0;
}
async function init() {
  anime = await fetch("/api/anime").then(r => r.json());
  [...new Set(anime.map(a => a.category).filter(Boolean))].forEach(c => {
    category.insertAdjacentHTML("beforeend", `<option value="${esc(c)}">${esc(c)}</option>`);
  });
  render();
}
search.addEventListener("input", render);
category.addEventListener("change", render);
init();