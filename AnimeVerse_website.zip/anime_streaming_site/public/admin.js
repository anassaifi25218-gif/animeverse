const loginBox = document.getElementById("loginBox");
const dashboard = document.getElementById("dashboard");
const loginForm = document.getElementById("loginForm");
const uploadForm = document.getElementById("uploadForm");
const loginMsg = document.getElementById("loginMsg");
const uploadMsg = document.getElementById("uploadMsg");
const adminList = document.getElementById("adminList");

function esc(s) {
  return String(s || "").replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
}
async function refresh() {
  const status = await fetch("/api/admin/status").then(r => r.json());
  loginBox.hidden = status.isAdmin;
  dashboard.hidden = !status.isAdmin;
  if (status.isAdmin) {
    const list = await fetch("/api/anime").then(r => r.json());
    adminList.innerHTML = list.map(a => `
      <div class="admin-item">
        <div><b>${esc(a.title)}</b><small>${esc(a.category)}</small></div>
        <button class="danger" onclick="removeAnime(${a.id})">Delete</button>
      </div>`).join("") || "<p class='muted'>No anime yet.</p>";
  }
}
loginForm.addEventListener("submit", async e => {
  e.preventDefault();
  const r = await fetch("/api/admin/login", {
    method:"POST", headers:{"Content-Type":"application/json"},
    body: JSON.stringify({password: document.getElementById("password").value})
  });
  loginMsg.textContent = r.ok ? "Login successful." : "Wrong password.";
  if (r.ok) refresh();
});
uploadForm.addEventListener("submit", async e => {
  e.preventDefault();
  uploadMsg.textContent = "Uploading...";
  const r = await fetch("/api/admin/anime", {method:"POST", body:new FormData(uploadForm)});
  const data = await r.json();
  uploadMsg.textContent = r.ok ? "Anime uploaded successfully!" : (data.error || "Upload failed");
  if (r.ok) { uploadForm.reset(); refresh(); }
});
document.getElementById("logout").onclick = async () => {
  await fetch("/api/admin/logout", {method:"POST"});
  refresh();
};
window.removeAnime = async id => {
  if (!confirm("Delete this anime?")) return;
  await fetch("/api/admin/anime/" + id, {method:"DELETE"});
  refresh();
};
refresh();